#!/usr/bin/env python

# Copyright 2007 Mark Taylor <skymt0@gmail.com>

version = "0.2"

# Copyright notice {{{

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

# }}}

# IMPORTANT NOTE: The spec allows for optional per-device trash dirs to
# eliminate delay caused by copying the file across devices. Thunar doesn't
# support it, so I won't (yet).  Instead, I'll follow what Thunar appears to
# do: move to the trash dir in ~, even across devices. This, for obvious
# reasons, means trashing items on slow devices (network drives, for example)
# will be slow. Very slow.

import sys, os, time

def printhelp():		# {{{
	"""Print a usage message to stdout."""
	print """Usage: trash FILE...
  or:  trash OPTION
Move FILE to a trash directory following the FreeDesktop.org trash
specification.

	  --help	  display this help and exit
	  --version		  output version information and exit

Report bugs to <skymt0@gmail.com>."""
# }}}

def printversion():		# {{{
	"""Print version information to stdout"""
	print """trash %s
Copyright 2007 Mark Taylor
This is free software.  You may redistribute copies of it under the terms of
the GNU General Public License <http://www.gnu.org/licenses/gpl.html>.
There is NO WARRANTY, to the extent permitted by law.

Written by Mark Taylor <skymt0@gmail.com>""" % version
# }}}

def parseopts():		# {{{
	if len(sys.argv) == 1:
		printhelp()
		sys.exit(1)
	
	if sys.argv[1] == "--help":
		printhelp()
		sys.exit(0)
	
	if sys.argv[1] == "--version":
		printversion()
		sys.exit(0)
# }}}

def gettrashdirs():		# {{{
	"""Find `files' and `info' directory locations according to the
FreeDesktop.org specs."""
	# Get the location of the trash dir
	xdgdatahome = os.getenv("XDG_DATA_HOME")
	if xdgdatahome:
		trashdir = xdgdatahome + "/Trash/"
	else:
		trashdir = os.getenv("HOME") + ".local/share/Trash/"
	
	filesdir = trashdir + "files/"
	infodir = trashdir + "info/"
	
	# Make sure it exists and is correctly set up
	for dir in [trashdir, filesdir, infodir]:
		if not os.path.isdir(dir):
			if not os.path.exists(dir):
				# no access for other users, a bit more secure (and restrictive)
				# than the Thunar implementation which gives r, w access to world
				os.mkdir(dir, 0700)
			else:
				print "trash: user trash directory", dir, "is not a directory"
				os.exit(1)
		# dir should be readable, writable, and executable
		if not os.access(dir, os.R_OK | os.W_OK | os.X_OK):
			print "trash: check permissions on", dir
			os.exit(1)
	return filesdir, infodir
# }}}

def trash(files):		# {{{
	filesdir, infodir = gettrashdirs()
	rmopts=('-rf', '-f', '-i', '-r', '-I', '-v')   # add options of rm you want trash to ignore
	for file in files:
		if file in rmopts:
			continue
		basename = os.path.basename(file)
		uniqname = basename
		counter = 1
		while os.path.exists(filesdir + uniqname):
			uniqname = basename + "$%d" % counter
			counter+=1
		try:
			ti = open(infodir + uniqname + ".trashinfo", "w")
			ti.write("[Trash Info]\n")
			ti.write("Path=%s\n" % os.path.abspath(file))
			ti.write("DeletionDate=%s\n" % time.strftime("%Y-%m-%dT%H:%M:%S"))
			ti.close()
		except IOError, ex:
			print "trash: cannot write metadata file `" + ex.filename + "': " + ex.strerror
			continue
		try:
			os.rename(file, filesdir + uniqname)
		except OSError, ex:
			# Minor race condition: if another process messes up the the trash
			# dir, this error message will be misleading
			os.remove(infodir + uniqname  + ".trashinfo")
			print "trash: cannot trash `" + file + "': " + ex.strerror
# }}}

if __name__ == "__main__":
	parseopts()
	trash(sys.argv[1:]) # default, if program doesn't exit in parseopts()

# vim:foldmethod=marker
